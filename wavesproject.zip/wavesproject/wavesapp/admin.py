from django.contrib import admin
from .models import Contact
from .models import Signup
from .models import Career
from .models import Form


# Register your models here.

admin.site.register(Contact)
admin.site.register(Signup)
admin.site.register(Career)
admin.site.register(Form)


