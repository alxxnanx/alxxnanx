from django.db import models


# Create your models here.


class Contact(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    emial=models.CharField(max_length=100)

    def str__(self):
         return self.firstname   


class Signup(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phonenumber=models.CharField(max_length=100)
    password=models.CharField(max_length=100)

    def str__(self):
        return self.firstname

class Career(models.Model):
    date=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    salary=models.CharField(max_length=100)
    exp=models.CharField(max_length=100)
    
    def str__(self):
        return self.post

class Form(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    experience=models.CharField(max_length=100)
    education=models.CharField(max_length=100)
    def str__(self):
        return self.name







