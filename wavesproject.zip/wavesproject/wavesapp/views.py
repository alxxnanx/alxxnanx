from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth
from .models import Contact
from .models import Signup
from .models import Career
from .models import Form


# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def service(request):
    return render(request,'services.html')

def gallary(request):
    return render(request,'gallary.html')

def contact(request):
    return render(request,'contact.html')

def home(request):
    return render(request,'index.html')

# def contact1(request):
#     if request.method=='post':
#         firstname=request.post['name']
#         lastname=request.post['name1']
#         phone=request.post['phn']
#         email=request.post['email']
#         obj=Contact.objects.create(firstname=firstname,lastname=lastname,phone=phone,emial=email)
#         obj.save()
#     return redirect('/')

def contact1(request):
    firstname=request.GET['name']
    lastname=request.GET['name1']
    phone=request.GET['phn']
    email=request.GET['email']
    obj=Contact.objects.create(firstname=firstname,lastname=lastname,phone=phone,emial=email)
    obj.save()
    return render(request,'index.html')

def signup(request):
    return render(request,'signup.html')

def register(request):
    firstname=request.GET['firstname']
    lastname=request.GET['lastname']
    email=request.GET['email']
    phonenumber=request.GET['phone']
    password=request.GET['password']
    user=Signup.objects.create(firstname=firstname,lastname=lastname,email=email,phonenumber=phonenumber,password=password)
    user.save()
    return render(request,'login.html')

def login(request):
    if request.method=='post':
        username=request.post['username']
        password=request.post['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('/s')
        else:
            return redirect('/signup')
    return render(request,'login.html') 

def career(request):
    details=Career.objects.all()
    return render(request,'career.html',{'details':details})


def apply(request):
    return render(request,'form.html')

# def form(request):
#     return render(request,'form.html')

def newapply(request):

    name=request.GET['name']
    email=request.GET['email']
    phone=request.GET['phone']
    obj=Form.objects.create(name=name,email=email,phone=phone)
    obj.save()
    return render(request,'form.html')






   


    