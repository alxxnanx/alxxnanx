from django.urls import path
from .import views

urlpatterns = [

    path('',views.index,name='index'),
    path('a',views.about,name='about'),
    path('s',views.service,name='service'),
    path('g',views.gallary,name='gallary'),
    path('contact',views.contact,name='contact'),
    path('contact1',views.contact1,name='contact1'),
    path('signup',views.signup,name='signup'),
    path('register',views.register,name='register'),
    path('login',views.login,name='login'),
    path('career',views.career,name='career'),
    # path('career1',views.career1,name='career1'),
    path('home',views.home,name='home'),
   
    path('apply',views.apply,name='apply'),
    path('newapply',views.newapply,name='newapply')

]